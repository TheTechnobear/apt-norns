#/bin/bash
sudo systemctl stop norns-jack.service
sleep 1

