#/bin/bash
sudo poweroff

