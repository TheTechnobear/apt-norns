#/bin/bash
sudo systemctl start norns-jack.service
sleep 1

