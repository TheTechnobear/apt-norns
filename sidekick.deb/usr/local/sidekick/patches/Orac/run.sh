#/bin/bash
echo starting orac
sudo systemctl start orac.service
sudo systemctl start mec.service

