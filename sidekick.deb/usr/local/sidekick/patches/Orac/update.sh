#/bin/bash
sudo apt install -y orac mec

