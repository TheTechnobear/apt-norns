#/bin/bash
sudo apt install orac mec

